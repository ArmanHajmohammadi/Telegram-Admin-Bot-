﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telegram.Bot.Types;
using System.Net.NetworkInformation;
using System.Net;
using System.Drawing.Text;
using System.Diagnostics.Contracts;
using System.Net.Cache;
using System.IO;
using System.Text.RegularExpressions;

namespace AdminBot
{
    public partial class Form1 : Form
    {
        private static string token = "";
        private Thread botThread;
        private Telegram.Bot.TelegramBotClient bot;
        private int counter = 0;
        private bool accessTelegram = false;
        private bool isConnected = false;
        private bool restartCheck = false;
        private string adminsID = "armanhajmohammadi#golitori#anonymousuts#romiw#everglott#mokian#farzin_baratpour#prst_pnh#parsa_aa_bagha#ali99e#untochableminde#ftm_jbbry#parsa_hbb#mamad_samar";

        public Form1()
        {
            InitializeComponent();
        }

        private void Startbtn_Click(object sender, EventArgs e)
        {
            accessTelegram = CheckForInternetConnection();
            if (accessTelegram)
            {
                token = txtToken.Text;
                botThread = new Thread(new ThreadStart(RunBot));
                botThread.Start();
            }
            else
            {
                errorText.Invoke(new Action(() =>
                {
                    errorText.ForeColor = Color.Red;
                    errorText.Text = "YOU'RE OFFLINE \n\a Please check your internet connection and try later!";
                }));
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (CheckForInternetConnection())
            {
                this.Invoke(new Action(() =>
                {
                    serverConnection.Text = "Can connect to the server";
                    serverConnection.ForeColor = Color.Green;
                }));
            }
            else
            {
                this.Invoke(new Action(() =>
                {
                    serverConnection.Text = "Can't connect to the server";
                    serverConnection.ForeColor = Color.Red;
                }));
            }
        }

        // EVERYTHING HAPPENS HERE : 
        void RunBot()
        {
        restart:
            bot = new Telegram.Bot.TelegramBotClient(token);
            this.Invoke(new Action(() =>
            {
                lblstatus.Text = "Connected to the server";
                lblstatus.ForeColor = Color.Green;
            }));
            errorText.Invoke(new Action(() =>
            {
                errorText.ForeColor = Color.Green;
                errorText.Text = "YOU'RE CONNECTED SUCCESSFULLY!";
            }));
            int offset = 0;
            while (true)
            {
                try
                {
                    accessTelegram = CheckForInternetConnection();
                    if (accessTelegram)
                    {
                        if (restartCheck == true)
                        {
                            restartCheck = false;
                            goto restart;
                        }
                        isConnected = true;
                        this.Invoke(new Action(() =>
                        {
                            serverConnection.Text = "Can connect to the server";
                            serverConnection.ForeColor = Color.Green;
                        }));

                        Telegram.Bot.Types.Update[] update = bot.GetUpdatesAsync(offset).Result;

                        foreach (var up in update)
                        {
                            offset = up.Id + 1;

                            //null messages: 

                            if (up.Message == null)
                            {
                                continue;
                            }
                            else
                            {
                                #region FORWARDED
                                ////forwarded messages : 
                                //if (up.Message.ForwardFromChat != null)
                                //{
                                //    var forwardFrom = up.Message.ForwardFromChat.Type.ToString().ToLower();
                                //    var chatID = up.Message.Chat.Id;
                                //    var from = up.Message.From;

                                //    if (from.FirstName != "Telegram" && forwardFrom == "channel")
                                //    {
                                //        // Deleting message : 
                                //        var spamMessageID = up.Message.MessageId;
                                //        bot.DeleteMessageAsync(chatID, spamMessageID);
                                //        dgReport.Invoke(new Action(() =>
                                //        {
                                //            if (up.Message.Chat.Title != null)
                                //            {
                                //                dgReport.Rows.Add(up.Message.Chat.Title.ToString(), from.Username,
                                //                (from.FirstName + " " + from.LastName), "Ads", IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                //            }
                                //            else
                                //            {
                                //                dgReport.Rows.Add(up.Message.Chat.Id, from.Username,
                                //                (from.FirstName + " " + from.LastName), "Ads", IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                //            }
                                //            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                //            counter++;
                                //            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                //        }));
                                //    }
                                //}
                                #endregion FORWARDED

                                // System messages : 
                                if (SystemMessageChecker(up))
                                {
                                    var chatID = up.Message.Chat.Id;
                                    var spamMessageID = up.Message.MessageId;
                                    bot.DeleteMessageAsync(chatID, spamMessageID);
                                    dgReport.Invoke(new Action(() =>
                                    {
                                        string actionType = ActionTypeChecker(up);

                                        dgReport.Rows.Add(up.Message.Chat.Title, "Telegram", "System message", actionType, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                        counter++;

                                    }));
                                }

                                // text messages:
                                if (up.Message.Text != null)
                                {
                                    var text = up.Message.Text.ToLower();
                                    var from = up.Message.From;
                                    var chatID = up.Message.Chat.Id;
                                    var messageID = up.Message.MessageId;
                                    string username = "";

                                    // Start:
                                    if (text.Contains("/start"))
                                    {
                                        StringBuilder sb = new StringBuilder();
                                        // The message:
                                        sb.AppendLine("سلام " + from.FirstName + " " + from.LastName + " ☺️");
                                        sb.AppendLine("من پدرخوانده‌ی دانشگاه تهرانم 😎");
                                        sb.AppendLine("امیدوارم برات مفید باشم و بتونم بهت کمک کنم 😌");
                                        sb.AppendLine("سوالات رو توی [گروه دانشگاه تهران](https://t.me/UTGroups) میتونی بپرسی، دانشجو های دیگه هستن و حتما جواب سوالت رو پیدا می کنی :)");

                                        bot.SendTextMessageAsync(chatID, sb.ToString());
                                        dgReport.Invoke(new Action(() =>
                                        {
                                            if (up.Message.Chat.Title != null)
                                            {
                                                dgReport.Rows.Add(up.Message.Chat.Title.ToString(), from.Username,
                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            }
                                            else
                                            {
                                                dgReport.Rows.Add(up.Message.Chat.Id, from.Username,
                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            }
                                            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                            counter++;
                                            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                        }));

                                        continue;
                                    }

                                    if (from.Username != null)
                                    {
                                        username = from.Username.ToString().ToLower();

                                        try
                                        {
                                            if (adminsID.Contains(username))
                                            {
                                                // BOTFATHERDEL 
                                                if (text.Contains("delete"))
                                                {
                                                    int counter = Convert.ToInt32(text.Replace("delete ", ""));
                                                    if (counter > 2000)
                                                    {
                                                        counter = 2000;
                                                    }
                                                    for (int i = messageID; i > (messageID - counter); i--)
                                                    {
                                                        bot.DeleteMessageAsync(chatID, i);
                                                    }
                                                }
                                            }
                                        }
                                        catch
                                        {
                                            continue;
                                        }
                                        
                                        if (adminsID.ToLower().Contains(username)) { continue; }
                                    }

                                    // Channel Bots:
                                    if (from.Username == "Channel_Bot")
                                    {
                                        // Deleting message : 
                                        var spamMessageID = up.Message.MessageId;
                                        bot.DeleteMessageAsync(chatID, spamMessageID);

                                        // Kicking user : 
                                        bot.KickChatMemberAsync(chatID, from.Id);

                                        dgReport.Invoke(new Action(() =>
                                        {
                                            if (up.Message.Chat.Title != null)
                                            {
                                                dgReport.Rows.Add(up.Message.Chat.Title.ToString(), from.Username,
                                                (from.FirstName + " " + from.LastName), "Action: Channel Bot kicked!", IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            }
                                            else
                                            {
                                                dgReport.Rows.Add(up.Message.Chat.Id, from.Username,
                                                (from.FirstName + " " + from.LastName), "Action: Channel Bot kicked!", IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            }
                                            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                            counter++;
                                            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                        }));

                                        continue;
                                    }

                                    // Darolfanni:
                                    if (Darolfanni(Reworder(text.ToLower())))
                                    {
                                        // Deleting message : 
                                        var spamMessageID = up.Message.MessageId;
                                        bot.DeleteMessageAsync(chatID, spamMessageID);

                                        // Kicking user : 
                                        // bot.KickChatMemberAsync(chatID, from.Id);

                                        dgReport.Invoke(new Action(() =>
                                        {
                                            if (up.Message.Chat.Title != null)
                                            {
                                                dgReport.Rows.Add(up.Message.Chat.Title.ToString(), from.Username,
                                                (from.FirstName + " " + from.LastName), "Action: Darolfanni kicked!", IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            }
                                            else
                                            {
                                                dgReport.Rows.Add(up.Message.Chat.Id, from.Username,
                                                (from.FirstName + " " + from.LastName), "Action: Darolfanni kicked!", IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            }
                                            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                            counter++;
                                            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                        }));

                                        continue;
                                    }

                                    // Abusive words : 
                                    if (AbusiveWordChecker(Reworder(text.ToLower())))
                                    {
                                        // Deleting message : 
                                        var spamMessageID = up.Message.MessageId;
                                        bot.DeleteMessageAsync(chatID, spamMessageID);

                                        dgReport.Invoke(new Action(() =>
                                        {
                                            if (up.Message.Chat.Title != null)
                                            {
                                                dgReport.Rows.Add(up.Message.Chat.Title.ToString(), from.Username,
                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            }
                                            else
                                            {
                                                dgReport.Rows.Add(up.Message.Chat.Id, from.Username,
                                                (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                            }
                                            dgReport.FirstDisplayedScrollingRowIndex = counter;
                                            counter++;
                                            dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                        }));

                                        continue;
                                    }

                                    dgReport.Invoke(new Action(() =>
                                    {
                                        if (up.Message.Chat.Title != null)
                                        {
                                            dgReport.Rows.Add(up.Message.Chat.Title.ToString(), from.Username,
                                            (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                        }
                                        else
                                        {
                                            dgReport.Rows.Add(up.Message.Chat.Id, from.Username,
                                            (from.FirstName + " " + from.LastName), text, IranTime().ToString("yyyy/MM/dd - HH:mm"));
                                        }
                                        dgReport.FirstDisplayedScrollingRowIndex = counter;
                                        counter++;
                                        dgReport.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
                                    }));

                                }
                            }
                        }
                    }
                    else
                    {
                        if (isConnected == true)
                        {
                            botThread.Abort();
                            errorText.Invoke(new Action(() =>
                            {
                                errorText.ForeColor = Color.Red;
                                errorText.Text = "YOU'RE OFFLINE \n\a Please check your internet connection and try later!";
                            }));
                            isConnected = false;
                            this.Invoke(new Action(() =>
                            {
                                lblstatus.Text = "Not connected to the server";
                                lblstatus.ForeColor = Color.Red;
                            }));
                            this.Invoke(new Action(() =>
                            {
                                serverConnection.Text = "Can't connect to the server";
                                serverConnection.ForeColor = Color.Red;
                            }));
                        }
                        restartCheck = true;
                        continue;
                    }
                }
                catch (Exception error)
                {
                    if (isConnected == true)
                    {
                        errorText.Invoke(new Action(() =>
                        {
                            errorText.ForeColor = Color.Red;
                            errorText.Text = error.Message;
                        }));
                        isConnected = false;
                        this.Invoke(new Action(() =>
                        {
                            lblstatus.Text = "Not connected to the server";
                            lblstatus.ForeColor = Color.Red;
                        }));
                        this.Invoke(new Action(() =>
                        {
                            serverConnection.Text = "Can't connect to the server";
                            serverConnection.ForeColor = Color.Red;
                        }));
                    }
                    restartCheck = true;
                    continue;
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isConnected)
            {
                botThread.Abort();
            }
        }

        private void txtToken_TextChanged(object sender, EventArgs e)
        {

        }
        private void stopbtn_Click(object sender, EventArgs e)
        {
            errorText.Invoke(new Action(() =>
            {
                errorText.ForeColor = Color.Black;
                errorText.Text = "NO ERRORS.";
            }));
            this.Invoke(new Action(() =>
            {
                lblstatus.Text = "Not connected to the server";
                lblstatus.ForeColor = Color.Red;
            }));
            if (CheckForInternetConnection() && isConnected)
            {
                botThread.Abort();
            }
        }
        public static bool CheckForInternetConnection()
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    using (client.OpenRead("https://telegram.org/"))
                    {
                        return true;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        string Reworder(string text)
        {
            // Removing white spaces and other characters :
            text = text.Replace(" ", "");
            text = text.Replace("‌", "");
            text = text.Replace("1", "");
            text = text.Replace("2", "");
            text = text.Replace("3", "");
            text = text.Replace("4", "");
            text = text.Replace("5", "");
            text = text.Replace("6", "");
            text = text.Replace("7", "");
            text = text.Replace("8", "");
            text = text.Replace("9", "");
            text = text.Replace("0", "");
            text = text.Replace("/", "");
            text = text.Replace("*", "");
            text = text.Replace("-", "");
            text = text.Replace("+", "");
            text = text.Replace("÷", "");
            text = text.Replace("×", "");
            text = text.Replace("!", "");
            text = text.Replace("@", "");
            text = text.Replace("#", "");
            text = text.Replace("$", "");
            text = text.Replace("%", "");
            text = text.Replace("^", "");
            text = text.Replace("&", "");
            text = text.Replace("*", "");
            text = text.Replace(")", "");
            text = text.Replace("(", "");
            text = text.Replace("_", "");
            text = text.Replace("-", "");
            text = text.Replace("=", "");
            text = text.Replace("]", "");
            text = text.Replace("[", "");
            text = text.Replace("{", "");
            text = text.Replace("}", "");
            text = text.Replace("/", "");
            text = text.Replace("؟", "");
            text = text.Replace("?", "");
            text = text.Replace("\\", "");
            text = text.Replace("'", "");
            text = text.Replace("\"", "");
            text = text.Replace(";", "");
            text = text.Replace(":", "");
            text = text.Replace("؛", "");
            text = text.Replace("،", "");
            text = text.Replace("ٍ", "");
            text = text.Replace("ٌ", "");
            text = text.Replace("ً", "");
            text = text.Replace("»", "");
            text = text.Replace("«", "");
            text = text.Replace("ـ", "");
            text = text.Replace("ۀ", "");
            text = text.Replace("ّ", "");
            text = text.Replace("ِ", "");
            text = text.Replace("ُ", "");
            text = text.Replace("َ", "");
            text = text.Replace("ة", "");
            text = text.Replace("<", "");
            text = text.Replace(">", "");
            text = text.Replace("~", "");
            text = text.Replace("`", "");

            return text;
        }

        bool AbusiveWordChecker(string text)
        {

            if (text.Contains("ک*ر") || text.Contains("ک*"))
            {
                return true;
            }

            text = Reworder(text.ToLower());

            // Checking if the text has abusive words : 

            if (text.Contains("کسنن") || text.Contains("کصنن") || text.Contains("کسخوار") || text.Contains("کصخوار") ||
                text.Contains("کسخار") || text.Contains("کصخار") || text.Contains("خوارکصده") || text.Contains("خارکصده") ||
                text.Contains("خوارکسده") || text.Contains("خارکسده") || text.Contains("خوارکصه") || text.Contains("خوارکسه") ||
                text.Contains("خارکصه") || text.Contains("خارکسه") || text.Contains("کصکش") || text.Contains("کسکش") ||
                text.Contains("جنده") || text.Contains("جندگی") || text.Contains("گایید") || text.Contains("ننتو") ||
                text.Contains("کیرم") || text.Contains("پتیاره") || text.Contains("مادرتو") ||
                text.Contains("کیری") || text.Contains("کسشر") || text.Contains("کسوشر") || text.Contains("کصشر") ||
                text.Contains("کصوشر") || text.Contains("کسشعر") || text.Contains("کسوشعر") || text.Contains("کصوشعر") ||
                text.Contains("کصشعر") || text.Contains("کیر") || text.Contains("کصخل") || text.Contains("کسخل") ||
                text.Contains("kosekhar") || text.Contains("kosnan") || text.Contains("kosenan") || text.Contains("kharkos") ||
                text.Contains("gayid") || text.Contains("jende") || text.Contains("madarjend") || text.Contains("tokhmam") ||
                text.Contains("kiram") || text.Contains("koskesh") || text.Contains("gohnakhor") || text.Contains("nanato") ||
                text.Contains("madareto") || text.Contains("petiyare") || text.Contains("petiare") || text.Contains("tkhmm") ||
                text.Contains("jnde") || text.Contains("mdreto") || text.Contains("kososher") || text.Contains("kosesher") ||
                text.Contains("kssher") || text.Contains("kossher") || text.Contains("kos") || text.Contains("جاکش") ||
                text.Contains("مادرخراب"))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        bool Darolfanni(string text)
        {
            // Checking if the text has basij words : 
            if ((text.Contains("darolfanni") || text.Contains("darolfani") || text.Contains("https://t.me/darolfanni99") ||
                text.Contains("darolfanni99") || text.Contains("darolfani99") || text.Contains("https://t.me/darolfanni") ||
                text.Contains("درلفنی") || text.Contains("دارلفنی") || text.Contains("دارالفنی") || text.Contains("daneshjo_ut") || text.Contains("لفنی") ||
                text.Contains("خوابگاهیوتی") || text.Contains("همیار") || text.Contains("hamyarut") || text.Contains("خوابگاهيوتي") ||
                text.Contains("utserat") || text.Contains("hakim96_ut") || text.Contains("sepidar_ut") || text.Contains("khabgahut")) && (!text.Contains("@utgroups")))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        bool SystemMessageChecker(Telegram.Bot.Types.Update up)
        {
            if (up.Message.Type == Telegram.Bot.Types.Enums.MessageType.ChatMemberLeft ||
                                    up.Message.Type == Telegram.Bot.Types.Enums.MessageType.ChatMembersAdded ||
                                    up.Message.Type == Telegram.Bot.Types.Enums.MessageType.ChatPhotoChanged ||
                                    up.Message.Type == Telegram.Bot.Types.Enums.MessageType.ChatPhotoDeleted ||
                                    up.Message.Type == Telegram.Bot.Types.Enums.MessageType.ChatTitleChanged ||
                                    up.Message.Type == Telegram.Bot.Types.Enums.MessageType.MessagePinned ||
                                    up.Message.Type == Telegram.Bot.Types.Enums.MessageType.VoiceChatEnded ||
                                    up.Message.Type == Telegram.Bot.Types.Enums.MessageType.VoiceChatStarted)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        string ActionTypeChecker(Telegram.Bot.Types.Update up)
        {
            switch (up.Message.Type)
            {
                case Telegram.Bot.Types.Enums.MessageType.ChatMemberLeft:
                    return "Chat Member Left";
                case Telegram.Bot.Types.Enums.MessageType.ChatMembersAdded:
                    return "Chat Members Added";
                case Telegram.Bot.Types.Enums.MessageType.ChatPhotoChanged:
                    return "Chat Photo Changed.";
                case Telegram.Bot.Types.Enums.MessageType.ChatPhotoDeleted:
                    return "Chat Photo Deleted";
                case Telegram.Bot.Types.Enums.MessageType.ChatTitleChanged:
                    return "Chat Title Changed";
                case Telegram.Bot.Types.Enums.MessageType.MessagePinned:
                    return "Message Pinned";
                case Telegram.Bot.Types.Enums.MessageType.VoiceChatEnded:
                    return "Voice Chat Ended";
                case Telegram.Bot.Types.Enums.MessageType.VoiceChatStarted:
                    return "Voice Chat Started";
                default:
                    return "None";
            }
        }

        private DateTime IranTime()
        {
            return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Iran Standard Time");
        }

        private void dgReport_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
