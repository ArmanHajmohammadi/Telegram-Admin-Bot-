﻿namespace AdminBot
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.gbToken = new System.Windows.Forms.GroupBox();
            this.Startbtn = new System.Windows.Forms.Button();
            this.txtToken = new System.Windows.Forms.TextBox();
            this.stopbtn = new System.Windows.Forms.Button();
            this.gbrecentActions = new System.Windows.Forms.GroupBox();
            this.dgReport = new System.Windows.Forms.DataGridView();
            this.ChatID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Message = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MessageID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblstatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.serverConnection = new System.Windows.Forms.ToolStripStatusLabel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.Errors = new System.Windows.Forms.GroupBox();
            this.errorText = new System.Windows.Forms.RichTextBox();
            this.gbToken.SuspendLayout();
            this.gbrecentActions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgReport)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.Errors.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbToken
            // 
            this.gbToken.Controls.Add(this.Startbtn);
            this.gbToken.Controls.Add(this.txtToken);
            this.gbToken.Controls.Add(this.stopbtn);
            this.gbToken.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbToken.Location = new System.Drawing.Point(11, 15);
            this.gbToken.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbToken.Name = "gbToken";
            this.gbToken.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbToken.Size = new System.Drawing.Size(825, 79);
            this.gbToken.TabIndex = 0;
            this.gbToken.TabStop = false;
            this.gbToken.Text = "Token";
            // 
            // Startbtn
            // 
            this.Startbtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Startbtn.ForeColor = System.Drawing.Color.Green;
            this.Startbtn.Location = new System.Drawing.Point(700, 27);
            this.Startbtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Startbtn.Name = "Startbtn";
            this.Startbtn.Size = new System.Drawing.Size(119, 42);
            this.Startbtn.TabIndex = 1;
            this.Startbtn.Text = "Start";
            this.Startbtn.UseVisualStyleBackColor = true;
            this.Startbtn.Click += new System.EventHandler(this.Startbtn_Click);
            // 
            // txtToken
            // 
            this.txtToken.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtToken.Location = new System.Drawing.Point(6, 27);
            this.txtToken.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtToken.Multiline = true;
            this.txtToken.Name = "txtToken";
            this.txtToken.Size = new System.Drawing.Size(562, 42);
            this.txtToken.TabIndex = 0;
            this.txtToken.TextChanged += new System.EventHandler(this.txtToken_TextChanged);
            // 
            // stopbtn
            // 
            this.stopbtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stopbtn.ForeColor = System.Drawing.Color.Red;
            this.stopbtn.Location = new System.Drawing.Point(575, 27);
            this.stopbtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.stopbtn.Name = "stopbtn";
            this.stopbtn.Size = new System.Drawing.Size(119, 42);
            this.stopbtn.TabIndex = 2;
            this.stopbtn.Text = "Stop";
            this.stopbtn.UseVisualStyleBackColor = true;
            this.stopbtn.Click += new System.EventHandler(this.stopbtn_Click);
            // 
            // gbrecentActions
            // 
            this.gbrecentActions.Controls.Add(this.dgReport);
            this.gbrecentActions.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbrecentActions.Location = new System.Drawing.Point(11, 102);
            this.gbrecentActions.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbrecentActions.Name = "gbrecentActions";
            this.gbrecentActions.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbrecentActions.Size = new System.Drawing.Size(826, 316);
            this.gbrecentActions.TabIndex = 2;
            this.gbrecentActions.TabStop = false;
            this.gbrecentActions.Text = "Recent Actions";
            // 
            // dgReport
            // 
            this.dgReport.AllowUserToAddRows = false;
            this.dgReport.AllowUserToDeleteRows = false;
            this.dgReport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ChatID,
            this.UserName,
            this.Message,
            this.MessageID,
            this.Date});
            this.dgReport.Location = new System.Drawing.Point(6, 32);
            this.dgReport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgReport.Name = "dgReport";
            this.dgReport.ReadOnly = true;
            this.dgReport.RowHeadersWidth = 51;
            this.dgReport.Size = new System.Drawing.Size(812, 276);
            this.dgReport.TabIndex = 0;
            this.dgReport.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgReport_CellContentClick);
            // 
            // ChatID
            // 
            this.ChatID.HeaderText = "Chat Title";
            this.ChatID.MinimumWidth = 6;
            this.ChatID.Name = "ChatID";
            this.ChatID.ReadOnly = true;
            // 
            // UserName
            // 
            this.UserName.HeaderText = "UserName";
            this.UserName.MinimumWidth = 6;
            this.UserName.Name = "UserName";
            this.UserName.ReadOnly = true;
            // 
            // Message
            // 
            this.Message.HeaderText = "Full Name";
            this.Message.MinimumWidth = 6;
            this.Message.Name = "Message";
            this.Message.ReadOnly = true;
            // 
            // MessageID
            // 
            this.MessageID.HeaderText = "Message";
            this.MessageID.MinimumWidth = 6;
            this.MessageID.Name = "MessageID";
            this.MessageID.ReadOnly = true;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.MinimumWidth = 6;
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblstatus,
            this.serverConnection});
            this.statusStrip1.Location = new System.Drawing.Point(0, 552);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(13, 0, 1, 0);
            this.statusStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.statusStrip1.Size = new System.Drawing.Size(849, 26);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblstatus
            // 
            this.lblstatus.ForeColor = System.Drawing.Color.Red;
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(195, 20);
            this.lblstatus.Text = "Not Connected to the server";
            // 
            // serverConnection
            // 
            this.serverConnection.ForeColor = System.Drawing.Color.Red;
            this.serverConnection.Name = "serverConnection";
            this.serverConnection.Size = new System.Drawing.Size(184, 20);
            this.serverConnection.Text = "Can\'t connect to the server";
            // 
            // Errors
            // 
            this.Errors.Controls.Add(this.errorText);
            this.Errors.Location = new System.Drawing.Point(11, 426);
            this.Errors.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Errors.Name = "Errors";
            this.Errors.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Errors.Size = new System.Drawing.Size(825, 115);
            this.Errors.TabIndex = 4;
            this.Errors.TabStop = false;
            this.Errors.Text = "Errors";
            // 
            // errorText
            // 
            this.errorText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.errorText.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorText.Location = new System.Drawing.Point(7, 25);
            this.errorText.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.errorText.Name = "errorText";
            this.errorText.ReadOnly = true;
            this.errorText.Size = new System.Drawing.Size(812, 80);
            this.errorText.TabIndex = 0;
            this.errorText.Text = "NO ERRORS.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 578);
            this.Controls.Add(this.Errors);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.gbrecentActions);
            this.Controls.Add(this.gbToken);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Bot";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbToken.ResumeLayout(false);
            this.gbToken.PerformLayout();
            this.gbrecentActions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgReport)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.Errors.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbToken;
        private System.Windows.Forms.Button Startbtn;
        private System.Windows.Forms.TextBox txtToken;
        private System.Windows.Forms.GroupBox gbrecentActions;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lblstatus;
        private System.Windows.Forms.DataGridView dgReport;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox Errors;
        private System.Windows.Forms.RichTextBox errorText;
        private System.Windows.Forms.Button stopbtn;
        private System.Windows.Forms.ToolStripStatusLabel serverConnection;
        private System.Windows.Forms.DataGridViewTextBoxColumn ChatID;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Message;
        private System.Windows.Forms.DataGridViewTextBoxColumn MessageID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
    }
}

